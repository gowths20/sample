import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import { withStyles } from '@material-ui/core/styles';
import classNames from 'classnames';
import Typography from '@material-ui/core/Typography';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import { List, ListItem, Avatar, Button, Divider, Tabs, Tab } from '@material-ui/core';
import { FormControl, OutlinedInput } from '@material-ui/core';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';

import { Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions } from '@material-ui/core';
import Toolbar from '@material-ui/core/Toolbar';
import TextField from '@material-ui/core/TextField';
import i18n from '../../config/locale';
import { userService } from '../../_services/UserService';
import config from '../../config/config';
import { ToastContainer, toast } from 'react-toastify';
import Select from '@material-ui/core/Select';
import InputBase from '@material-ui/core/InputBase';
import renderHTML from 'react-render-html';
import { AppLoader, readSessionStorage, formatProviderDisplayName } from '../Helpers';



const styles = theme => ({
	root:{	
	},
	container: {
		display: 'flex',
		flexWrap: 'wrap',
	},
	bullet: {
		display: 'inline-block',
		margin: '0 2px',
		transform: 'scale(0.8)',
	},
	pos: {
		marginBottom: 12,
	},
	avatar: {
	},
	send_message_button: {
		borderRadius: '1em',
		textTransform: 'capitalize',
		float: 'right'
	},
	height:{
		height: 8
	},
	error: {},
	disabled: {}
});



function TabContainer(props) {
	return (
		<Typography component="div" style={{ padding: 8 * 3 }}>
			{props.children}
		</Typography>
	);
}

class MessagesList extends Component {
	state = {
		value: 0,
		openWindow: false,
		open: false,
		index: 0
	}

	async updateMessage(i, message_id, patient_id) {

		this.setState(
			{
				openWindow: true,
				open: false,
				index: i
			}
		);

		if (message_id && patient_id) {
			let requestOptions = {
				"PATIENT_ID": patient_id,
				"ID": message_id,
				"IS_READ": true
			};

			let response = await userService.update_message(requestOptions);
			this.props.parent.pullMessages(false);
		}
	}

	handleClickOpenMessageWindow = (i, message_id, patient_id) => {
		this.updateMessage(i, message_id, patient_id);
	}

	handleClosedialogWindow = () => {
		this.setState({ openWindow: false });
	};

	handleChange = (event, value) => {
		this.setState({ value });
	};

	getProviderName(message) {
		var provider = "";
		if (message.FROM === 'clinic' || message.TO === 'clinic') {
			provider = this.props.parent.state.clinics.filter(c => c.clinicId === message.PROVIDER_ID)[0];
			if (provider) {
				provider = provider.clinicName;
			}
		} else if (message.FROM === 'provider' || message.TO === 'provider') {
			provider = this.props.parent.state.providers.filter(p => p.providerId === message.PROVIDER_ID)[0];
			if (provider) {
				provider = formatProviderDisplayName(provider);
			}
		}

		return provider;
	}

	render() {
		const { value } = this.state;
		const { messages, providers, clinics } = this.props.parent.state;
		let unread_msgs = messages.filter(m => m.TO === 'patient' && !m.IS_READ).length;
		return <div>
			<Tabs
				disableRipple
				value={value}
				onChange={this.handleChange}
				indicatorColor="none">
				<Tab label={<Typography style={{fontWeight: 'inherit'}} color="inherit" className="large-body">{unread_msgs > 0 ? "Inbox (" + unread_msgs + ")" : "Inbox"}</Typography>} />
				<Tab label={<Typography style={{fontWeight: 'inherit'}} color="inherit" className="large-body">Sent</Typography>} />
			</Tabs>
			{value === 0 && <TabContainer>
				<List>
					{
						messages.map((message, i) => (
							message.TO === 'patient' ? <ListItem style={{ cursor: 'pointer' }} divider dense alignItems={'flex-start'} key={i} >
								<Grid container onClick={this.handleClickOpenMessageWindow.bind(this, i, message.ID, message.PATIENT_ID)}>
									<Grid item xs={2} md={1}>
										<Avatar aria-label="">
										</Avatar>
									</Grid>
									<Grid item xs={8} md={9}>
										<Typography 
										variant="subheading"
										component="span"
										  className={message.IS_READ ? '' : 'bold primary-color large-body'}>
											{
												this.getProviderName(message)
											}
										</Typography>
										<Typography variant="subheading"
										  className={message.IS_READ ? '' : 'bold unread-message body' }>
											{message.SUBJECT}
										</Typography>
									</Grid>
									<Grid item xs={2} md={2}>
										<Typography variant="caption" className="body">
											{new Date(message.TIME).toLocaleDateString()} {new Date(message.TIME).toLocaleTimeString()}
										</Typography>
									</Grid>
								</Grid>
							</ListItem> : ''
						))
					}
				</List>
			</TabContainer>}
			{value === 1 && <TabContainer>
				<List>
					{
						messages.map((message, i) => (
							message.FROM === 'patient' ? <ListItem divider dense alignItems={'flex-start'} key={i} >
								<Grid container onClick={this.handleClickOpenMessageWindow.bind(this, i)}>
									<Grid item xs={2} md={1}>
										<Avatar aria-label="">
										</Avatar>
									</Grid>
									<Grid item xs={8} md={9} style={{ maxHeight: '3em' }}>
										<Typography className="bold large-body">
											{
												this.getProviderName(message)
											}
										</Typography>
										<Typography className="body">
											{message.SUBJECT}
										</Typography>
									</Grid>
									<Grid item xs={2} md={2}>
										<Typography variant="caption" className="body">
											{new Date(message.TIME).toLocaleDateString()} {new Date(message.TIME).toLocaleTimeString()}
										</Typography>
									</Grid>
								</Grid>
							</ListItem> : ''

						))
					}
				</List>
			</TabContainer>}


			<Dialog open={this.state.openWindow}
				onClose={this.handleClosedialogWindow}
				aria-labelledby="form-dialog-title"
				className={'dialog'}
			>
				<Toolbar>
					<IconButton className="close-icon" color="inherit" onClick={this.handleClosedialogWindow} aria-label="Close">
						<CloseIcon />
					</IconButton>
					<Typography component="span" variant="h6" className="bold title">Message</Typography>
				</Toolbar>
				<Grid item xs={12}><hr/></Grid>
				<DialogContent>
				<Grid container style={{ padding: '0 24px' }}>
					<DialogContentText>
						{
							messages.map((message, i) => (
								(i == this.state.index ? <div key={i}><Grid container>

									<Grid item xs={4}> <Typography className="large-body">From: </Typography></Grid>
									<Grid item xs={6}>
										<Typography className="large-body">
											{
												message.FROM == 'patient' ? 'You' : this.getProviderName(message)
											}
										</Typography>
									</Grid>

								</Grid>
									<Grid container>

										<Grid item xs={4}> <Typography className="large-body">To: </Typography></Grid>
										<Grid item xs={8}>
											<Typography className="large-body">
												{
													message.TO == 'patient' ? 'You' : this.getProviderName(message)
												}
											</Typography>
										</Grid>

									</Grid>
									<Grid container>

										<Grid item xs={4}> <Typography className="large-body">Subject: </Typography></Grid>
										<Grid item xs={8}> <Typography className="large-body">{message.SUBJECT} </Typography></Grid>

									</Grid>
									<Grid container>

										<Grid item xs={4}> <Typography className="large-body">Message: </Typography></Grid>
										<Grid item xs={8}> <Typography className="large-body">{renderHTML(message.BODY)} </Typography></Grid>

									</Grid>


								</div>


									: "")

							))
						}

					</DialogContentText>
					</Grid>
				</DialogContent>

			</Dialog>
		</div>
	}
}

class Messages extends Component {
	state = {
		messages: [],
		open: false,
		openWindow: false,
		index: 0,
		provider_id: "",
		patient_id: "",
		subject: "",
		message: "",
		providers: [],
		clinics: []
	}


	handleClose = () => {
		this.setState({ open: false });
	};

	showToastMessage(message) {
		toast(message, {
			position: toast.POSITION.BOTTOM_RIGHT,
			type: toast.TYPE.INFO,
			autoClose: 5000,
			closeButton: null
		});

	}

	async handleClosewithMsgSent() {
		AppLoader('show');
		let user = readSessionStorage('user');
		let [to_type, provider_id] = this.state.provider_id.split('~#~#~');
		let requestOptions = {
			"PATIENT_ID": user.sub,
			"PROVIDER_ID": provider_id,
			"FROM": 'patient',
			"TO": to_type,
			"SUBJECT": this.state.subject,
			"BODY": this.state.message,
			"TIME": new Date()
		};

		await userService.send_message(requestOptions);
		this.showToastMessage('Message is sent!');
		this.pullMessages(false);
		this.setState({ subject: '', provider_id: '', message: '' });
		AppLoader('hide');
	};

	handleClosedialogWindow = () => {
		this.setState({ openWindow: false });
	};
	handleClickOpen = () => {
		this.setState({ open: true });
	};
	constructor(props) {
		super(props);
		//~ this.handleChange = this.handleChange.bind(this);
		this.pullMessages = this.pullMessages.bind(this);
	}

	handleChange = name => e => {
		const value = e.target.value;
		this.setState({ [name]: value });
	}

	getUnique(arr, comp) {

		const unique = arr
			.map(e => e[comp])

			// store the keys of the unique objects
			.map((e, i, final) => final.indexOf(e) === i && i)

			// eliminate the dead keys & store unique objects
			.filter(e => arr[e]).map(e => arr[e]);

		return unique;
	}

	async getAllDoctors() {
		var user = JSON.parse(sessionStorage.getItem('user'));
		let response = await userService.getAllAppointment(user["sub"]);
		let getall_completed_appointments = await userService.getAllCompletedAppointment(user["sub"]);
		let allappointments = await response.content.concat(getall_completed_appointments.content);
		var unique_providers = [];
		var unique_clinics = [];

		if (allappointments.length > 0) {
			unique_clinics = this.getUnique(allappointments, 'clinicId');
			unique_providers = this.getUnique(allappointments, 'providerId');
			this.setState({ providers: unique_providers, clinics: unique_clinics });
		}

		return unique_providers;
	}

	async pullMessages(open) {
		let user = readSessionStorage('user');
		let requestOptions = {
			"PATIENT_ID": user.sub
		};
		var response = await userService.pull_messages(requestOptions);
		this.setState({ messages: response, open: open });

		return response;
	}

	handleChangeDoctor = name => event => {
		this.setState({ [name]: event.target.value });
	}

	componentDidMount() {
		this.getAllDoctors();
		this.pullMessages();
	}

	render() {
		const { classes } = this.props;
		const { providers, clinics } = this.state;


		const { provider_id, subject, message } = this.state;

		const isEnabled = provider_id.length > 0 && subject.length > 0 && message.length > 0;
		//~ const isEnabled = true;

		return (
			<div>
				<ToastContainer />
				<Grid container spacing={24} className="white-bg">
					<Grid item xs={12}>
						<Grid container>
							<Grid item xs={6}>
								<Typography variant="h6" className="bold subheading">
									Messages
                                <ChevronRightIcon className='arrow-icon' />
								</Typography>
							</Grid>

							<Grid item xs={0} md={3}></Grid>

							<Grid item xs={6} md={3}>
								<Button variant="text" fullWidth className="button-secondary" onClick={this.handleClickOpen}>
									Send Message
                            	</Button>
							</Grid>
						</Grid>
					</Grid>

					<Grid item xs={12}>
						<Divider />
						<MessagesList parent={this} />
					</Grid>
				</Grid>
				{this.state.open?<NewMessage></NewMessage>:null}
				{/* <Dialog className={'dialog'}
					open={this.state.open}
					onClose={this.handleClose}
					aria-labelledby="form-dialog-title">

					<Toolbar>
						<IconButton className="close-icon" color="inherit" onClick={this.handleClose} aria-label="Close">
							<CloseIcon />
						</IconButton>
						<Typography className="bold title" component="span" variant="h6">Compose Message</Typography>
					</Toolbar>
					<Grid item xs={12}><hr/></Grid>

					<DialogContent className={'dialog-content background-lighter'}>
					<Grid container style={{ padding: '0 24px' }}>
						<DialogContentText component="div">

							<Grid container style={{ marginTop: "20px", textAlign: 'left' }}>
								<Grid item xs={12} style={{ marginBottom: 8 }}>
									<Typography className="body" variant="subtitle2" style={{ paddingBottom: 5 }}><b>To</b></Typography>
									<FormControl fullWidth>
										<Select native value={this.state.provider_id}
											onChange={this.handleChange('provider_id')}
											className="large-body"
											input={
												<OutlinedInput 
												classes={classes} name="provider_id" />
											}>
											<option> - Please Select - </option>
											<optgroup label="Clinic">
												{
													clinics.map(c => (
														<option key={c.clinicId} value={'clinic~#~#~' + c.clinicId}> {c.clinicName}</option>
													))
												}
											</optgroup>
											<optgroup label="Provider">
												{
													providers.map(p => (
														<option key={p.providerId} value={'provider~#~#~' + p.providerId}> {formatProviderDisplayName(p)}</option>
													))
												}
											</optgroup>
										</Select>
									</FormControl>
								</Grid>

								<Grid item xs={12} style={{ marginBottom: 8 }}>
									<Typography className="body" variant="subtitle2" style={{ paddingBottom: 5 }}><b>Subject</b></Typography>
									<FormControl fullWidth>
										<TextField
											variant="outlined"
											name='subject'
											className={'large-body outlined-input white-bg'}
											value={this.state.subject}
											onChange={this.handleChange('subject')}
										/>
									</FormControl>
								</Grid>

								<Grid item xs={12} style={{ marginBottom: 8 }}>
									<Typography variant="subtitle2"><b>Message</b></Typography>
									<TextField
										multiline={true}
										margin="normal"
										className="large-body white-bg"
										variant="outlined"
										rows={4}
										value={this.state.message}
										onChange={this.handleChange('message')}
										style={{ width: '100%', marginTop: 8}}
										/>

								</Grid>
							</Grid>

							<Grid container style={{ marginTop: "20px" }}>
								<Grid item xs={4}><Button
									fullWidth
									variant="outlined"
									className='button-outlined'
									onClick={this.handleClose}
								>
									{i18n.cancel}
								</Button></Grid>
								<Grid item xs={4}></Grid>
								<Grid item xs={4}><Button
									fullWidth
									type="submit"
									variant="flat"
									className='button-secondary'
									onClick={this.handleClosewithMsgSent.bind(this)}
									disabled={!isEnabled}
								>
									Send
                                            </Button></Grid>
							</Grid>
						</DialogContentText>
						</Grid>
					</DialogContent>
				</Dialog> */}
			</div>

		);
	}
}

export default withStyles(styles)(Messages);