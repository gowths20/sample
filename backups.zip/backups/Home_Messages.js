import { Avatar, Button, Divider, List, ListItem } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import { NavLink } from 'react-router-dom';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import React, { Component } from 'react';
import renderHTML from 'react-render-html';
import { userService } from '../../../_services/UserService';
import { readSessionStorage } from '../../Helpers';


const styles = theme => ({
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    bullet: {
        display: 'inline-block',
        margin: '0 2px',
        transform: 'scale(0.8)',
    },
    pos: {
        marginBottom: 12,
    },
    avatar: {
    },
    send_message_button: {
        borderRadius: '1em',
        textTransform: 'capitalize',
        float: 'right'
    }
});
class HomeMessages extends Component {
    state = {
        messages: [],
        clinic_names: {}
    }

    getAllDoctors() {
        if (this.props.upcoming.length > 0 || this.props.completed.length > 0) {
            let allAppointments = this.props.upcoming.concat(this.props.completed);
            var clinic_names = {};
            if (allAppointments.length > 0) {
                for (let i = 0; i < allAppointments.length; i++) {
                    if(!clinic_names[allAppointments[i]['clinicId']]) {
                        clinic_names[allAppointments[i]['clinicId']] = allAppointments[i]['clinicName'];
                    }
                }
                this.setState({ clinic_names: clinic_names });
            }
        }
    }

    async pullMessages() {
        let user = readSessionStorage('user');
        let requestOptions = {
            "PATIENT_ID": user.sub
        };
        var response = await userService.pull_messages(requestOptions);
        this.setState({ messages: response });

    }

    componentDidMount() {
        this.getAllDoctors();
        this.pullMessages();
    }

    componentWillReceiveProps(props) {
        if (props.upcoming.length > 0 || props.completed.length > 0) {
            let allAppointments = props.upcoming.concat(props.completed);
            var clinic_names = {};
            if (allAppointments.length > 0) {
                for (let i = 0; i < allAppointments.length; i++) {
                    if(!clinic_names[allAppointments[i]['clinicId']]) {
                        clinic_names[allAppointments[i]['clinicId']] = allAppointments[i]['clinicName'];
                    }
                }
                this.setState({ clinic_names: clinic_names });
            }
        }
        this.pullMessages();
    }

    render() {
        const { classes } = this.props;
        const { messages, clinic_names } = this.state;

        return (<Grid container spacing={24} className="white-bg" >
            <Grid item xs={12}>
                <Grid container>
                    <Grid item xs={10}>
                        <Typography variant="h6" className="bold subheading">
                            Your Messages
                                <ChevronRightIcon className='arrow-icon' />
                        </Typography>
                    </Grid>
                    {/* <Grid item xs={0} md={4}></Grid> */}
                    <Grid item xs={2}>
                        <NavLink to="/messages" className="a-link">
                        <Typography className={'body a_link'} style={{ paddingTop: 5,textAlign:'right' }}>
                            View All
                            <ChevronRightIcon className='arrow-icon' />
                        </Typography>
                        </NavLink>
                    </Grid>
                </Grid>
            </Grid>

            <Grid item xs={12}>
                <List>
                    {messages.filter(m => m.TO === 'patient').length > 0 ?
                        messages.slice(0,5).filter(m => m.TO === 'patient').map((message, i) => (
                            <ListItem divider dense alignItems={'flex-start'} key={i}>
                                <Grid container>
                                    <Grid item xs={2} md={1}>
                                        <Avatar aria-label="" className={classes.avatar}>
                                        </Avatar>
                                    </Grid>
                                    <Grid item xs={10} md={11}>
                                        <Typography component="span" className={message.IS_READ ? 'large-body' : 'bold unread-message large-body' }>
                                            {
                                                clinic_names[message.PROVIDER_ID] ? clinic_names[message.PROVIDER_ID] : '...'
                                            }
                                        </Typography>
                                        <Typography style={{float: 'right'}} variant="subheading" className="body">
                                            {new Date(message.TIME).toLocaleDateString()} {new Date(message.TIME).toLocaleTimeString()}
                                        </Typography>
                                        <Typography style={{width: '80%'}} variant="subheading" className="body">
                                            {renderHTML(message.SUBJECT)}
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </ListItem>
                        )) :
                        <Grid container style={{ textAlign: 'center' }}>
                            <Grid item xs={3} >
                                <Typography variant="h6" variant="large-body">No recent messages</Typography>
                            </Grid>
                        </Grid>
                    }
                </List>
            </Grid>
            <Grid item xs={8}>&nbsp;</Grid>
            <Grid item xs={4}>
                <Button fullWidth variant="outlined" className="button-outlined">
                    Compose New Message
                </Button>
            </Grid>
        </Grid>);
    }
}

export default withStyles(styles)(HomeMessages);