import { Divider, List } from '@material-ui/core';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import React, { Component } from 'react';
import RecommendationsList from '../Recommendations';

class HomeMedicalResources extends Component {

    render() {

        return (<Grid container spacing={24}  className="white-bg" >
            <Grid item xs={8} style={{paddingBottom: 0}}>
                <Typography variant="h6" className="bold subheading">
                    Medical Resources
                        <ChevronRightIcon className='arrow-icon' />
                </Typography>
            </Grid>
            <Grid item xs={2}></Grid>
            <Grid item xs={2}>
                    {/* <NavLink to="/bills_insurance_details" className="a-link"> */}
                    <Typography className={'body a_link'} style={{ paddingTop: 5,textAlign:'right' }} onClick={this.handleClickOpenModel3}>
                        View All
                    <ChevronRightIcon className='arrow-icon' />
                    </Typography>
                    {/* </NavLink> */}
            </Grid>
            <Grid item xs={12} style={{paddingTop: 0}}>
                <List style={{paddingTop: 0}}>
                    <RecommendationsList limit="3" />
                </List>
            </Grid>
        </Grid>);
    }
}

export default HomeMedicalResources;