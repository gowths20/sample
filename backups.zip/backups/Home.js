import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import HomeHealthRecords from './home/Home_HealthRecords';
import HomeMessages from './home/Home_Messages';
import HomeAppointments from './home/Home_Appointments';
import HomeMedications from './home/Home_Medications';
import HomeMedicalResources from './home/Home_MedicalResources';
import YourBills from './home/YourBills';
import { userService } from '../../_services/UserService';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import i18n from '../../config/locale';

class HomePage extends Component {
    state = {
        loaded: false,
        loaded_medications: false,
        upcomingAppointment: [],
        getAllCompletedAppointments: []
    }

    showToastMessage(message) {
        toast(message, {
            position: toast.POSITION.TOP_LEFT,
            type: toast.TYPE.WARNING,
            autoClose: 5000,           
            closeButton: null
        });

    }
    async componentDidMount() {
        if (!sessionStorage.getItem('member_data')) {
            var member_data = await userService.get_patient_data('002bc6a2-b35e-44cf-a29f-f0b7132ba33e');
            sessionStorage.setItem('member_data', JSON.stringify(member_data));
            this.setState({ loaded_medications: true });
        }
        if(sessionStorage.getItem("showToast")){
            this.showToastMessage(i18n.signedIn);
        }        
        var user = JSON.parse(sessionStorage.getItem('user'));
        let upcomingAppointment = await userService.getAllAppointment(user["sub"]);
        let getAllCompletedAppointments = await userService.getAllCompletedAppointment(user["sub"]);
        sessionStorage.removeItem("showToast");
        this.setState({
            upcomingAppointment: upcomingAppointment.content,
            getAllCompletedAppointments: getAllCompletedAppointments.content,
            loaded: true
        })
    }

    render() {
        const { loaded, upcomingAppointment, getAllCompletedAppointments } = this.state;
        console.log(this.state);

        return (

            <Grid container className = "home" spacing={8}>
                 <ToastContainer />
                <Grid item xs={12}><HomeHealthRecords parent_loaded={loaded} history = {this.props.history} completed={getAllCompletedAppointments} upcoming={upcomingAppointment} /></Grid>
                <Grid item xs={12}>&nbsp;</Grid>
                <Grid item xs={12}>&nbsp;</Grid>
                <Grid item xs={12}><HomeAppointments parent={this} upcoming={upcomingAppointment} /></Grid>
                <Grid item xs={12}>&nbsp;</Grid>
                <Grid item xs={12}><HomeMessages parent={this} completed={getAllCompletedAppointments} upcoming={upcomingAppointment} /></Grid>
                <Grid item xs={12}>&nbsp;</Grid>
                {/* <Grid item xs={12}><HomeMedications parent={this} /></Grid>
                <Grid item xs={12}>&nbsp;</Grid> */}
                <Grid item xs={12}><YourBills parent={this} /></Grid>
                <Grid item xs={12}>&nbsp;</Grid>
                <Grid item xs={12}><HomeMedicalResources /></Grid>
            </Grid>);
    }
}

export default HomePage;