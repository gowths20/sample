import React, { PureComponent } from 'react'
import Iframe from 'react-iframe';
import {AppLoader, readSessionStorage } from '../Helpers';
import config from '../../config/config';
import FrameLoadingImg from '../../assets/images/frame_loading3.gif';
import { userService } from '../../_services/UserService';
import { Redirect } from 'react-router-dom';

export default class Symptom extends PureComponent {
    state = {  
        "init": true,
        head_html: "",
        body_html :"",
        redirect:false
    }
    
    async componentDidMount() {
        console.log(this.props)
        /**var cssLink = document.createElement("link");
        cssLink.href = "assets/css/inline.css"; 
        cssLink.rel = "stylesheet"; 
        cssLink.type = "text/css"; 
        document.querySelector("iframe").contentWindow.document.body.appendChild(cssLink);
        */
       this.setState({redirect:true});
        var self = this;
        window.onhashchange = function(evt) { 
            if(self.props.parent.props.location.search)
            {
            self.props.parent.props.location.search = ""
            window.location.reload();
            }
          }
        AppLoader("show");
        let response = await userService.get_symptoms_checker();
        AppLoader("hide");

        this.setState({body_html : response.bodyHtml, head_html : response.headHtml});
    }
    
    render() {
        const {init, body_html, head_html} = this.state
       console.log(body_html)
        if (init) {
        return (
            // <div style={{backgroundImage: `url(${FrameLoadingImg})`,backgroundRepeat:"no-repeat",backgroundPosition:"center",backgroundSize:"200px" }}>
            <div>
                <iframe srcDoc={head_html + body_html}
                        frameBorder="0"
                        style={{width: '100%', height: '850px'}} />
            </div>
        )
    } else {
        return (<div>Loading ......</div>)
    }
  }
}
