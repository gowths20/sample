import React from 'react';
import PropTypes from 'prop-types';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import withStyles from '@material-ui/core/styles/withStyles';
import Grid from '@material-ui/core/Grid';
import { List, ListItem, Divider, Paper, Select, OutlinedInput, FormControl, NativeSelect } from '@material-ui/core';
import { NavLink } from 'react-router-dom';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';


const styles = theme => ({
    root: {
        flexGrow: 1,
    },
    grow: {
        flexGrow: 1,
    },
    paper: {
        border: '1px solid',
        boxShadow: 'none',
        padding: 8,
        width: '75%',
        textAlign: 'center'
    },
    date: {
        fontWeight: 'bold'
    },
    time: {

    },
    doctor_info: {
        padding: '8px 0'
    },
    tab: {
        textTransform: 'capitalize'
    }
});

class YourBills extends React.Component {

    state = {
        view_by_year: 'this_year',
        type: 0,
        labelWidth: 0,
        current_payments: [],
        past_payments: []
    };

    handleChange = (event, value) => {
        this.setState({ value });
    };

    componentDidMount() {
        this.setState({
            current_payments: [
                {
                    date: 'May 26 2019',
                    time: '2:15 PM',
                    description: 'Wellness exam',
                    health_center: 'Walmart Health Medford',
                    doctor: 'April Cooper, MD',
                    amount: '65.00',
                    currency: '$'
                },
                {
                    date: 'May 26 2019',
                    time: '3:30 PM',
                    description: 'Vision check-up',
                    health_center: 'Walmart Health Medford',
                    doctor: 'Nathan G, MD',
                    amount: '65.00',
                    currency: '$'
                }
            ],
            past_payments: [
                {
                    date: 'Feb 26 2019',
                    time: '2:15 PM',
                    description: 'Wellness exam',
                    health_center: 'Walmart Health Medford',
                    doctor: 'April Cooper, MD',
                    amount: '65',
                    currency: '$'
                },
                {
                    date: 'Feb 26 2019',
                    time: '3:30 PM',
                    description: 'Vision check-up',
                    health_center: 'Walmart Health Medford',
                    doctor: 'Nathan G, MD',
                    amount: '65',
                    currency: '$'
                },
                {
                    date: 'Jan 26 2019',
                    time: '2:15 PM',
                    description: 'Wellness exam',
                    health_center: 'Walmart Health Medford',
                    doctor: 'Grace Bahnda, MD',
                    amount: '65',
                    currency: '$'
                }
            ]
        });
    }

    render() {
        const { classes } = this.props;

        const { current_payments, past_payments } = this.state;
        return (
            <div>
                <Grid container className={'white-bg'} spacing={24}>
                    <Grid item xs={12}>
                        <Grid container>
                            <Grid item xs={8}>
                                <Typography variant="h6" className="bold subheading">
                                    Your Bills
                                    <ChevronRightIcon className='arrow-icon' />
                                </Typography>
                            </Grid>
                            <Grid item xs={2}></Grid>
                            <Grid item xs={2}>
                                    {/* <NavLink to="/bills_insurance_details" className="a-link"> */}
                                    <Typography className={'body a_link'} style={{ paddingTop: 5,textAlign:'right' }} onClick={this.handleClickOpenModel3}>
                                        View All
                                    <ChevronRightIcon className='arrow-icon' />
                                    </Typography>
                                    {/* </NavLink> */}
                            </Grid>
                        </Grid>
                    </Grid>

                    <Grid item xs={12}>
                        <Divider />
                        <List>
                            {
                                current_payments.map((payment, i) => (
                                    <ListItem divider dense alignItems={'flex-start'} key={i}>
                                        <Grid container>
                                            <Grid item xs={2}>
                                                <Typography>
                                                    <Button variant="outlined" className="button-outlined">
                                                        Pay
                                                    </Button>
                                                </Typography>
                                            </Grid>

                                            <Grid item xs={7}>
                                                <Typography className={'bold large-body'}>
                                                    {payment.date}
                                                </Typography>
                                                <Typography className="large-body">
                                                    {payment.description} with {payment.doctor}
                                                </Typography>
                                            </Grid>

                                            <Grid item xs={2}>
                                                <Typography className={'bold large-body'}>
                                                    You Owe:
                                                </Typography>
                                                <Typography className="large-body">
                                                    {payment.currency}{payment.amount}
                                                </Typography>
                                            </Grid>

                                            <Grid item xs={1}>
                                                <Typography className={'arrow-icon'}>
                                                    <ChevronRightIcon className='arrow-icon' />
                                                </Typography>
                                            </Grid>
                                        </Grid>
                                    </ListItem>
                                ))
                            }
                        </List>
                    </Grid>
                </Grid>
                
            </div>
        );
    }
}

YourBills.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(YourBills);